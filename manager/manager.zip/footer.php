<?php if (!defined('ACCESS')) die('Not access'); ?>

        </div>
        <div id="footer">
            <span>&bull; &bull; IZeroCs &bull; &bull;</span>
        </div>
    </body>
</html>
<?php ob_end_flush(); ?>